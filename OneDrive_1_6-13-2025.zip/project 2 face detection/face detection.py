import cv2

alg = "haarcascade_frontalface_default.xml" #initializing algorithm

haar_cascade = cv2.CascadeClassifier(alg) #loading algorithm

cam = cv2.VideoCapture(0) #cam id initialization

while True:

    _,img = cam.read() #reading the frame from camera

    grayimg = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY) #converting color to gray

    faces = haar_cascade.detectMultiScale(grayimg,1.3,4) #getting coordinates

    for (x,y,w,h) in faces :
        cv2.rectangle(img,(x,y),(x+w,y+h),(0,0,255),2) #drawing rectang;e
    cv2.imshow("face detection",img)

    key = cv2.waitKey(10)
    if key == 27:          #value of escape key is 27
        break
    
cam.release()
cv2.destroyAllWindows()
