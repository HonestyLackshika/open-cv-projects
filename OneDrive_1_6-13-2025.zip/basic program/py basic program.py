import cv2
img = cv2.imread("novitech.png") #read an image
cv2.imshow("show",img) #to display an image
cv2.imwrite("photo.jpg",img) #to save an image
cv2.waitKey(3000) #3000 ms = 3 sec
cv2.destroyAllWindows()
