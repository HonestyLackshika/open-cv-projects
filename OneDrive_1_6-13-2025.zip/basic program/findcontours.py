#cv2.findContours(srcImageCopy,contourRetrievalMode,contourApproximationMethod

cnts = cv2.findContours(threshImg.copy(),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
