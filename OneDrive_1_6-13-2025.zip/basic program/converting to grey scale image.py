import cv2
img = cv2.imread("novitech.png")
greyimage = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY) #convert tp gray
cv2.imshow("original",img)
cv2.imshow("grey",greyimage)
cv2.imwrite("grayImage.jpg",greyimage)

print(img.shape)#no.of rows and columns and colors   ---> BGR - 3 , gray scale/binary image - 1
print(img.size)
