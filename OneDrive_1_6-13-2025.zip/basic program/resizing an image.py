import cv2
import imutils

img = cv2.imread("photo.jpg")
resizedImg = imutils.resize(img,width=100)
cv2.imshow("original",img)
cv2.imshow("resized",resizedImg)

cv2.imwrite("resizedimage.jpg",resizedImg)
