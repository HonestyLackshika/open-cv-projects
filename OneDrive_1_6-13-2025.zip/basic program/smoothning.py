import cv2

img = cv2.imread("photo.jpg")

                                #(src ,(kernal), border type)
UsualgaussianImg = cv2.GaussianBlur(img,(21,21),0) #usual blur
gaussianImg = cv2.GaussianBlur(img,(41,41),50)

cv2.imshow("original",img)
cv2.imshow("usualBlur",UsualgaussianImg)
cv2.imshow("blur",gaussianImg)
