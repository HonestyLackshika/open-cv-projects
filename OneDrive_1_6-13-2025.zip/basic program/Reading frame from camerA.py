import cv2

vs = cv2.VideoCapture(0) #initializing camera 0- main camera 1-aditional camera

while True:
    _,img = vs.read() # _ <-- variable 1 , it shows true or falls if we give any value

    cv2.imshow("videoStream",img)

    key = cv2.waitKey(1)

    print(key)


    if key == ord("q"): #to close the loop ............. until press q the value of the key will be -1 when presses it will 113
            break
    
vs.release()
cv2.DestroyAllWindows()




#print(ord("q")) #ASCII Value of ord("q") is 113

# can input any alphabet for closing. not only q
