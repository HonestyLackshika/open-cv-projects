import cv2

img = cv2.imread("photo.jpg")

#cv2.rectangle(src,startpoint,endpoint,color,thickness)
rectanle = cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),2)
print(rectangle)
